# Yong Deng
# Final Exam 
# Extra credit
# 6-26-2015

from tkinter import *
from flask import Flask
import sqlite3
import tkinter



conn = sqlite3.connect("final_exam.sqlite")
cursor = conn.cursor()
results = cursor.execute("select Number, StudentName from EXAM WHERE StudentName is not null").fetchall()

total_games = 0	


base = Tk()
base.configure(bg='white')
base.geometry("400x400")
# base.minsize(300, 300)
base.maxsize(1000, 1000)
frame = tkinter.Frame(base)
frame.pack()
Label(frame, text="Exam Number", foreground="red").pack(side=LEFT, padx = 20)
Label(frame, text="Student Name", foreground="blue").pack(side=LEFT, padx = 20)

for stu in results:
	fr=tkinter.Frame(base)
	Label(fr, text=stu[0], foreground="red").pack(side=LEFT, padx = 20)
	Label(fr, text=stu[1], foreground="blue").pack(side=LEFT, padx = 20)
	fr.pack()

base.mainloop()
