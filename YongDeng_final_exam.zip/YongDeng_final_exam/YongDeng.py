# Yong Deng
# Final Exam
# 6-26-2015

import sqlite3
from wsgiref.simple_server import make_server

def get_form_vals(post_str):
	form_vals = {item.split("=")[0]: item.split("=")[1] for item in post_str.decode().split("&")}
	return form_vals

def exam_app(environ, start_response):
	#print("ENVIRON:", environ)
	message=""
	status = '200 OK'
	headers = [('Content-type', 'html; charset=utf-8')]
	start_response(status, headers)

	conn = sqlite3.connect("final_exam.sqlite")
	cursor = conn.cursor()

	message += "<html><head><style>*{font-size:16px;}"
	message += "body{padding-top:5px;margin:auto;width:60%;font-family:sans-serif;} h1{font-size: 24px; font-weight:bold;}"
	message += "table{font-size:14px; width:auto;} input{font-size:14px; width='100'}</style></head>"
	message += "<br><h1>FINAL EXAM</h1><p>Add record:</p>"
	message += "<form method='POST'><br>Exam Number:<input type=text name='exam_number'>"
	message += "<br><br>Student Name:<input type=text name='stu_name'>"
	message += "<br><br><input type='submit' name='Submit' ></form>"

	#Processing request using POST method
	if(environ['REQUEST_METHOD'] == 'POST'):
		request_body_size = int(environ['CONTENT_LENGTH'])
		request_body = environ['wsgi.input'].read(request_body_size)
		form_vals = get_form_vals(request_body)

		try:
			cursor.execute("UPDATE EXAM SET StudentName =? WHERE Number=?", (form_vals["stu_name"], form_vals["exam_number"]))
		except Exception as e:
			print(e)
			message += "<div>ALERT! An error occured when updating the database!</div>"

	# print(results)
	results = cursor.execute("select Number, StudentName from EXAM WHERE StudentName is not null").fetchall()
	if (results):
		# message += "<h3>Below is the summary of the exam table:</h3>"
		message += "<table cellpadding='15' cellspacing='0' border='2'>"
		message += "<tr><th bgcolor='aquamarine' align = 'left'>Exam Number</th>"
		message += "<th bgcolor='aquamarine' align = 'left'>Student Name</th><br>"
		for stu in results:
			message += "<tr><td bgcolor='lime'>"+str(stu[0])+"</td><td bgcolor='darkturquoise'>"+stu[1]+"</td></tr><br>"
		message += "</table></body>"
	
	conn.commit()
	conn.close()

	return[bytes(message,'utf-8')]

httpd = make_server('', 8000, exam_app)
print("Serving on port 8000...")
httpd.serve_forever()


